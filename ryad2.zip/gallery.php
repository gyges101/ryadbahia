

<?php include 'navbar.php'; ?>
<!-- MAin menu ends -->

<style>
#sizer {
  display: inline-block;
  max-width:20%;
  max-height: 40%
}

.cont {


}
</style>

<!-- Start welcome section -->
<section class="welcome-section-5 sec-padding">
    <div class="container ">
        <div class="row col-lg-12 col-sm-12 col-xs-12">
          <div id="lightgallery">
              <a href="bahia/1.jpg" id='sizer'>
                <img src="bahia/1.jpg">
              </a>
              <a href="bahia/2.jpg" id='sizer'>
                <img src="bahia/2.jpg">
              </a>
              <a href="bahia/3.jpg" id='sizer'>
                <img src="bahia/3.jpg">
              </a>
              <a href="bahia/4.jpg" id='sizer'>
                <img src="bahia/4.jpg">
              </a>
              <a href="bahia/5.jpg" id='sizer'>
                <img src="bahia/5.jpg">
              </a>
              <a href="bahia/6.jpg" id='sizer'>
                <img src="bahia/6.jpg">
              </a>
              <a href="bahia/7.jpg" id='sizer'>
                <img src="bahia/7.jpg">
              </a>
              <a href="bahia/8.jpg" id='sizer'>
                <img src="bahia/8.jpg">
              </a>
              <a href="bahia/9.jpg" id='sizer'>
                <img src="bahia/9.jpg">
              </a>
              <a href="bahia/14.jpg" id='sizer'>
                <img src="bahia/14.jpg">
              </a>
              <a href="bahia/17.jpg" id='sizer'>
                <img src="bahia/17.jpg">
              </a>
              <a href="bahia/20.jpg" id='sizer'>
                <img src="bahia/20.jpg">
              </a>
              <a href="bahia/28.jpg" id='sizer'>
                <img src="bahia/28.jpg">
              </a>
              <a href="bahia/29.jpg" id='sizer'>
                <img src="bahia/29.jpg">
              </a>
              <a href="bahia/30.jpg" id='sizer'>
                <img src="bahia/30.jpg">
              </a>
              <a href="bahia/31.jpg" id='sizer'>
                <img src="bahia/31.jpg">
              </a>
              <a href="bahia/32.jpg" id='sizer'>
                <img src="bahia/32.jpg">
              </a>
              <a href="bahia/33.jpg" id='sizer'>
                <img src="bahia/33.jpg">
              </a>
              <a href="bahia/34.jpg" id='sizer'>
                <img src="bahia/34.jpg">
              </a>
          </div>
        </div>
      </div>
</section>

<script>
    lightGallery(document.getElementById('lightgallery'));

</script>

<?php include 'bottom.php'; ?>